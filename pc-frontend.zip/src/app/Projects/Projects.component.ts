import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-projects',
  templateUrl: './Projects.component.html',
  styleUrls: ['./Projects.component.css']
})

export class ProjectsComponent{

}
