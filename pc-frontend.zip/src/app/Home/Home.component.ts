import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './Home.component.html',
  styleUrls: ['./Home.component.css']
})

export class HomeComponent{

}
