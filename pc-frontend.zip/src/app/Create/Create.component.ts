import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-create',
  templateUrl: './Create.component.html',
  styleUrls: ['./Create.component.css']
})

export class CreateComponent{

}
