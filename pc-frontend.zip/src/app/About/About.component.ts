import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './About.component.html',
  styleUrls: ['./About.component.css']
})

export class AboutComponent{

}
