import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-pledges',
  templateUrl: './Pledges.component.html',
  styleUrls: ['./Pledges.component.css']
})

export class PledgesComponent{

}
