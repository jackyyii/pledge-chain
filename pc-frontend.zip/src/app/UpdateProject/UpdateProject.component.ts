import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-project',
  templateUrl: './UpdateProject.component.html',
  styleUrls: ['./UpdateProject.component.css']
})
export class UpdateProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
