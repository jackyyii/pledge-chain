import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-pledge-type',
  templateUrl: './AddPledgeType.component.html',
  styleUrls: ['./AddPledgeType.component.css']
})
export class AddPledgeTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
