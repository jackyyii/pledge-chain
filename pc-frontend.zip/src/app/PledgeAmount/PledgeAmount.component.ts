import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pledge-amount',
  templateUrl: './PledgeAmount.component.html',
  styleUrls: ['./PledgeAmount.component.css']
})
export class PledgeAmountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
